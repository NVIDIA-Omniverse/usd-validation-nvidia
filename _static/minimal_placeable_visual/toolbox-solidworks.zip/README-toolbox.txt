﻿This is a placeholder for toolbox-solidworks.zip
The actual file will be added later.
